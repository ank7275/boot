package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;

@org.springframework.stereotype.Service
public class Service {
	@Autowired
	AdminRepository adminRepository;

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	ProductRepository productRepository;

	@Autowired
	CardRepository cardRepository;

	@Autowired
	OrderRepository orderRepository;

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	TransactionRepository transactionRepository;

	@Autowired
	UsersRepository usersRepository;

	@PersistenceContext
	private EntityManager entityManager;

	public String login(String id, String pass) {

		if (usersRepository.existsByUsernameAndPasswordAndRole(id, pass, "ADMIN")) {
			return "admin";
		}
		if (usersRepository.existsByUsernameAndPasswordAndRole(id, pass, "USER")) {
			return "customer";
		}
		return "fail";
	}

	public void saveadmin(Admin admin) {
		if (!adminRepository.existsById(admin.getAdminEmail()))
			adminRepository.save(admin);
	}

	public List<Admin> getAdmins() {
		List<Admin> admins = new ArrayList<>();
		adminRepository.findAll().forEach(admins::add);
		return admins;
	}

	public void deleteAdmin(String id) {
		adminRepository.deleteById(id);
	}

	public void savecustomer(Customer customer) {
		if (!customerRepository.existsById(customer.getUsername()))
			customerRepository.save(customer);
	}

	public void deleteCustomer(String id) {
		customerRepository.deleteById(id);
	}

	public List<Customer> getCustomers() {
		List<Customer> customers = new ArrayList<>();
		customerRepository.findAll().forEach(customers::add);
		return customers;
	}

	public Optional<Users> getDetails(String email) {
		return usersRepository.findById(email);
	}

	public void addproduct(Product product) {
		productRepository.save(product);
	}

	public List<Product> getAllProducts() {
		List<Product> products = new ArrayList<Product>();
		productRepository.findAll().forEach(products::add);
		return products;
	}

	public List<Product> getAllProductAdmin(String user) {
		List<Product> products = new ArrayList<>();
		products = productRepository.findAllBypostedBy(user);
		return products;
	}

	public Optional<Product> getProduct(int id) {
		return productRepository.findById(id);
	}

	public List<Product> search(String val) {
		Session session = null;
		if (entityManager == null || (session = entityManager.unwrap(Session.class)) == null) {

			throw new NullPointerException();
		}
		List<Product> products = null;
		if (val == null || val.trim().equals("")) {
			products = this.getAllProducts();
			return products;
		} else {
			Criteria criteria = session.createCriteria(Product.class).add(Restrictions.ilike("proName", val + "%"));
			return criteria.list();
		}
	}

	public List<Product> searchByCategory(int cid) {

		List<Product> products = productRepository.findAllBycatId(cid);
		return products;
	}

	public void savecard(Card card) {
		cardRepository.save(card);
	}

	public List<Card> getCards(String user) {
		List<Card> cards = new ArrayList<Card>();
		cardRepository.findAll().forEach(cards::add);
		return cards;
	}

	public void deleteCard(String cno) {
		cardRepository.deleteById(cno);
	}

	public void removeProduct(int id) {
		productRepository.deleteById(id);
	}

	public void saveOrders(Orders orders) {
		orderRepository.save(orders);
	}

	public void addCategory(Category category) {
		categoryRepository.save(category);
	}

	public void deleteCategory(int catId) {
		categoryRepository.deleteById(catId);
	}

	public List<Category> getCategory() {
		List<Category> categories = new ArrayList<Category>();
		categoryRepository.findAll().forEach(categories::add);
		return categories;
	}

	public List<Orders> getAllOrders(String user) {
		List<Orders> orders = orderRepository.findByuid(user);
		return orders;
	}

	public Transaction cancelOrder(String oid) {
		return transactionRepository.findByoid(oid);
	}

	public void savetrans(Transaction transaction) {
		transactionRepository.save(transaction);
	}
}
