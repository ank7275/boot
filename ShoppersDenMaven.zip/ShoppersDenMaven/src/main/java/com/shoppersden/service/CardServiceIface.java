package com.shoppersden.service;

import java.util.List;

import com.shoppersden.model.Card;

public interface CardServiceIface {
	String addCardService(Card obj);

	String deleteCardService(String cno);

	List<Card> getAllCardService(String user);
}
