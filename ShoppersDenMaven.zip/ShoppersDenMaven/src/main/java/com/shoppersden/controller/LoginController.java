package com.shoppersden.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.shoppersden.model.Admin;
import com.shoppersden.model.Customer;
import com.shoppersden.service.AdminServiceIface;
import com.shoppersden.service.CustomerServiceIface;

/**
 * @author Indralok
 *
 */
@Controller
public class LoginController {
	@Autowired
	CustomerServiceIface customerIface;

	@Autowired
	AdminServiceIface adminIface;

	@RequestMapping("/Loginform")
	public String showLoginForm() {
		return "Loginform";
	}

	@RequestMapping("/Login")
	public ModelAndView login(@RequestParam("name") String id, @RequestParam("pass") String password,
			HttpServletRequest request) {
		HttpSession session = request.getSession();
		Admin admin = adminIface.verifyAdminService(id, password);
		Customer customer = customerIface.verifyCustomerService(id, password);
		if (admin != null) {
			session.setAttribute("name", admin.getAdminName());
			return new ModelAndView("redirect:/showAllProductAdmin");
		} else if (customer != null) {
			session.setAttribute("cname", customer.getcEmail());
			return new ModelAndView("redirect:/CustomerPage");
		} else {
			return new ModelAndView("Loginform", "msg", "Invalid Credentials");
		}
	}

	@RequestMapping("/showAdminForm")
	public String showAdminForm(Model m) {
		m.addAttribute("admin", new Admin());
		return "AdminRegister";
	}

	@RequestMapping("/AddAdmin")
	public ModelAndView addAdmin(@Valid @ModelAttribute("admin") Admin admin, BindingResult br) {
		if (br.hasErrors()) {
			return new ModelAndView("AdminRegister");
		} else {
			String msg = adminIface.registerAdminService(admin);
			return new ModelAndView("AdminRegister", "msg", msg);
		}
	}

	@RequestMapping("/CheckEmail")
	public ModelAndView checkEmail(@RequestParam("val") String adminId) {
		return new ModelAndView("CheckEmailAdmin", "msg", adminIface.checkEmailExistanceService(adminId));
	}

	@RequestMapping("/showCustomerForm")
	public String showCustomerForm() {
		return "CustomerRegistration";
	}

	@RequestMapping("/addCustomer")
	public ModelAndView addAdmin(@ModelAttribute Customer customer) {
		String msg = customerIface.addCustomerService(customer);
		return new ModelAndView("CustomerRegistration", "msg", msg);
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session, HttpServletRequest request,Model m) {
		session = request.getSession();
		session.removeAttribute("cname");
		session.removeAttribute("name");
		session.invalidate();
		m.addAttribute("logout","true");
		return "Loginform";
	}

	@RequestMapping("/ForgotPassword")
	public String forgotPasswordForm() {
		return "ForgotPassword";
	}

	@RequestMapping("/validateId")
	public String validateId(@RequestParam("name") String id, Model m) {
		if (customerIface.validateIdService(id) > 0) {
			m.addAttribute("name", id);
			return "changepassword";
		} else {
			m.addAttribute("msg","Invalid ID");
			return "ForgotPassword";
		}

	}

	@RequestMapping("/UpdatePassword")
	public String updatePassword(@RequestParam("name") String id, @RequestParam("pass") String pass, Model m) {
		customerIface.updatePasswordService(id, pass);
		m.addAttribute("msg", "password changed");
		return "Loginform";

	}
}
