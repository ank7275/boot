package com.example.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.ServletConfigAware;
import org.springframework.web.context.ServletContextAware;

import com.google.gson.Gson;

@org.springframework.stereotype.Controller
public class Controller implements ServletConfigAware, ServletContextAware {
	private ArrayList<Cart> carts = null;
	private ServletContext context = null;
	private ServletConfig config = null;

	@Autowired
	Service service;

	@Override
	public void setServletContext(ServletContext servletContext) {
		this.context = servletContext;

	}

	@Override
	public void setServletConfig(ServletConfig servletConfig) {
		this.config = servletConfig;

	}

	@RequestMapping("/home")
	public String home(ModelMap modelMap) {
		List<Product> products = service.getAllProducts();
		modelMap.addAttribute("products", products);
		modelMap.addAttribute("cart", carts);
		return "home";
	}

	@RequestMapping("/Login")
	public String login(@RequestParam("name") String id, @RequestParam("pass") String pass, HttpServletRequest request,
			ModelMap modelMap) {
		System.out.println(service.login(id, pass));
		if (service.login(id, pass).equals("customer")) {
			HttpSession session = request.getSession();
			session.setAttribute("user", id);
			List<Product> products = service.getAllProducts();
			Optional<Customer> optional = service.getDetails(id);
			if (optional.isPresent()) {
				Customer customer = (Customer) optional.get();
				modelMap.addAttribute("customer", customer);
			}
			modelMap.addAttribute("products", products);
			return "Customer";
		} else if (service.login(id, pass).equals("admin")) {
			HttpSession session = request.getSession();
			session.setAttribute("user", id);
			List<Product> products = service.getAllProducts();
			modelMap.addAttribute("products", products);
			return "Admin";
		} else {
			return "redirect:/home";
		}
	}
	
	@RequestMapping("/customer")
	public String customer(ModelMap modelMap) {
		List<Product> products = service.getAllProducts();
		modelMap.addAttribute("products", products);
		modelMap.addAttribute("cart", carts);
		return "Customer";
	}

	@RequestMapping("/admin")
	public String admin(ModelMap modelMap,HttpServletRequest request) {
		HttpSession session=request.getSession();
		List<Product> products = service.getAllProductAdmin((String)session.getAttribute("user"));
		modelMap.addAttribute("products", products);
		return "Admin";
	}

	@RequestMapping("/AddAdmin")
	public String registeradmin(@ModelAttribute Admin admin) {
		service.saveadmin(admin);
		return "home";
	}

	@RequestMapping("/AddCustomer")
	public String registercustomer(@ModelAttribute Customer customer,HttpSession session,HttpServletRequest request) {
		service.savecustomer(customer);
		session=request.getSession();
		if(session==null) {
		return "home";
		}else {
			return "redirect:/customer";
		}
	}

	@RequestMapping("/GetDetails")
	public void getCustDetails(@RequestParam("email") String email, HttpServletResponse response) {
		Optional<Customer> optional = service.getDetails(email);
		if (optional.isPresent()) {
			Customer customer = (Customer) optional.get();
			String json = new Gson().toJson(customer);
			PrintWriter printWriter;
			try {
				printWriter = response.getWriter();
				printWriter.print(json);
			} catch (IOException e) {
// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	@RequestMapping("/addProduct")
	public String addProduct(@ModelAttribute Product product,HttpServletRequest request) {
		HttpSession session=request.getSession();
		product.setPostedBy((String)session.getAttribute("user"));
		service.addproduct(product);
		return "redirect:/admin";
	}

	@RequestMapping("/updateProduct")
	public void getProDetails(@RequestParam("id") int id, HttpServletResponse response) {
		Optional<Product> optional = service.getProduct(id);
		if (optional.isPresent()) {
			Product product = (Product) optional.get();
			System.out.println(product);
			String json = new Gson().toJson(product);
			PrintWriter printWriter;
			try {
				printWriter = response.getWriter();
				printWriter.print(json);
			} catch (IOException e) {
// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}
	
	@RequestMapping("/RemoveProduct")
	public String removepro(@RequestParam("id") int id) {
		service.removeProduct(id);
		return "redirect:/admin";
	}

	@RequestMapping("/AjaxSearch")
	public String search(@RequestParam("val") String val, ModelMap modelMap) {
		List<Product> products = service.search(val);
		modelMap.addAttribute("products", products);
		return "home";
	}

	@RequestMapping("/AddToCart")
	public String addToCart(@RequestParam("id") int pid, @RequestParam("name") String name,
			@RequestParam("price") int price, @RequestParam("qty") int qty, HttpServletRequest request, Model m) {
		HttpSession session = request.getSession();
        String addby = (String) session.getAttribute("user");
		Cart cart = new Cart(name, pid, 1,addby, price, qty);
		int flag = 0;
		if (carts == null) {
			carts = new ArrayList<Cart>();
		}

		for (Cart cart1 : carts) {
			if (cart1.getName().equals(cart.getName())&&cart1.getAddby().equals(addby)) {
				increaseQty(name, request);
				flag = 1;
			}
		}

		if (flag == 0) {
			carts.add(cart);
		}
		return "redirect:/viewCart";
	}

	@RequestMapping("/removeProduct")
	public String removeProduct(@RequestParam("name") String name, HttpServletRequest request) {
		HttpSession session = request.getSession();
        String addby = (String) session.getAttribute("user");
		for (int i = 0; i < carts.size(); i++) {
			Cart cart = carts.get(i);
			if (cart.getName().equals(name)&&cart.getAddby().equals(addby)) {
				carts.remove(i);
			}
		}
		return "redirect:/viewCart";
	}

	@RequestMapping("/decreaseProduct")
	public String decreaseQty(@RequestParam("name") String name, HttpServletRequest request) {
		HttpSession session = request.getSession();
        String addby = (String) session.getAttribute("user");
		for (Cart cart1 : carts) {
			if (cart1.getName().equals(name)&&cart1.getAddby().equals(addby)) {
				if (cart1.getQty() == 1) {
					removeProduct(name, request);
				} else {
					cart1.setPrice(cart1.getPrice() - (cart1.getPrice() / cart1.getQty()));
					cart1.setQty(cart1.getQty() - 1);
				}
			}
		}
		return "redirect:/viewCart";
	}

	@RequestMapping("/increaseProduct")
	public String increaseQty(@RequestParam("name") String name, HttpServletRequest request) {
		HttpSession session = request.getSession();
		String addby = (String) session.getAttribute("user");
		String str = null;
		for (int i = 0; i < carts.size(); i++) {
			Cart p = carts.get(i);
			if (p.getName().equals(name)&&p.getAddby().equals(addby)) {
				if (p.getQty() == p.getpQty()) {
					str = name + " is not sufficiently available";
				} else {
					p.setPrice(p.getPrice() + p.getPrice() / p.getQty());
					p.setQty(p.getQty() + 1);
					str = "increased";
				}
			}
		}
		return "redirect:/viewCart";
	}

	@RequestMapping("/viewCart")
	public String viewCart(HttpServletRequest request) {
		HttpSession session = request.getSession();
		if (session == null) {
			return "redirect:/home";
		} else {
			return "redirect:/customer";
		}
	}

	@RequestMapping("/addCard")
	public String addcard(@ModelAttribute Card card) {
		service.savecard(card);
		return "redirect:/customer";
	}

	@RequestMapping("/GetCards")
	public void getCards(@RequestParam("user") String user, HttpServletResponse response) {
		List<Card> cards = service.getCards(user);
		String json = new Gson().toJson(cards);
		PrintWriter printWriter;
		try {
			printWriter = response.getWriter();
			printWriter.print(json);
		} catch (IOException e) {
// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@RequestMapping("/logout")
	public String invalidate(HttpServletRequest request) {
		HttpSession session=request.getSession();
		session.removeAttribute("user");
		session.invalidate();
		return "redirect:/home";
	}

}