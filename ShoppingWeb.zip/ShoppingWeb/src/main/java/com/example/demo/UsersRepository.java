package com.example.demo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsersRepository extends CrudRepository<Users,String> {

	public boolean existsByUsernameAndPasswordAndRole(String id,String pass,String role);
	
	public Users findByUsername(String username); 
}
