package com.shoppersden.dao;

import java.util.List;

import com.shoppersden.model.Cart;

public interface CartDaoIface {
	List<Cart> getAllOrderedItems();
	void saveAllorders(Cart cart);
}
