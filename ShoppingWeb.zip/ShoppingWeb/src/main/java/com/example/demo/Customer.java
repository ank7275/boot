package com.example.demo;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@DiscriminatorValue(value = "customers")
public class Customer extends Users{
	@Column
	private String cName;
	@Column
	private String cGender;
	@Column
	private String cAddress;
	@Column
	private String cContact;
	@Column
	private String cDob;



	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public String getcGender() {
		return cGender;
	}

	public void setcGender(String cGender) {
		this.cGender = cGender;
	}

	public String getcAddress() {
		return cAddress;
	}

	public void setcAddress(String cAddress) {
		this.cAddress = cAddress;
	}

	
	public String getcContact() {
		return cContact;
	}

	public void setcContact(String cContact) {
		this.cContact = cContact;
	}

	public String getcDob() {
		return cDob;
	}

	public void setcDob(String cDob) {
		this.cDob = cDob;
	}

}
