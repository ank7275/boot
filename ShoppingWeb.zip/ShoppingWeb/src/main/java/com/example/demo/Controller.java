package com.example.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.gson.Gson;

@org.springframework.stereotype.Controller
public class Controller {
	private ArrayList<Cart> carts = null;

	@Autowired
	Service service;

	@RequestMapping("/home")
	public String home(ModelMap modelMap) {
		List<Product> products = service.getAllProducts();
		modelMap.addAttribute("products", products);
		modelMap.addAttribute("cart", carts);
		return "home";
	}

	@RequestMapping("/admin")
	public String admin(ModelMap modelMap) {
		List<Product> products = service.getAllProducts();
		modelMap.addAttribute("products", products);
		return "Admin";
	}

	@RequestMapping("/customer")
	public String customer() {
		return "Customer";
	}

	@RequestMapping("/AddAdmin")
	public String registeradmin(@ModelAttribute Admin admin) {
		service.saveadmin(admin);
		return "home";
	}

	@RequestMapping("/AddCustomer")
	public String registercustomer(@ModelAttribute Customer customer) {
		service.savecustomer(customer);
		return "home";
	}

	@RequestMapping("/GetDetails")
	public void getCustDetails(@RequestParam("email") String email, HttpServletResponse response) {
		Optional<Customer> optional = service.getDetails(email);
		if (optional.isPresent()) {
			Customer customer = (Customer) optional.get();
			String json = new Gson().toJson(customer);
			PrintWriter printWriter;
			try {
				printWriter = response.getWriter();
				printWriter.print(json);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	@RequestMapping("/addProduct")
	public String addProduct(@ModelAttribute Product product) {
		service.addproduct(product);
		return "redirect:/admin";
	}

	@RequestMapping("/updateProduct")
	public void getProDetails(@RequestParam("id") int id, HttpServletResponse response) {
		Optional<Product> optional = service.getProduct(id);
		if (optional.isPresent()) {
			Product product = (Product) optional.get();
			System.out.println(product);
			String json = new Gson().toJson(product);
			PrintWriter printWriter;
			try {
				printWriter = response.getWriter();
				printWriter.print(json);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	@RequestMapping("/AjaxSearch")
	public String search(@RequestParam("val") String val, ModelMap modelMap) {
		List<Product> products = service.search(val);
		modelMap.addAttribute("products", products);
		return "home";
	}

	@RequestMapping("/AddToCart")
	public String addToCart(@RequestParam("id") int pid, @RequestParam("name") String name,
			@RequestParam("price") int price, @RequestParam("qty") int qty, HttpServletRequest request, Model m) {
		HttpSession session = request.getSession();
		//String addby = (String) session.getAttribute("user");
		Cart cart = new Cart(name, pid, 1,"ankit", price, qty);
		int flag = 0;
		if (carts == null) {
			carts = new ArrayList<Cart>();
		}

		for (Cart cart1 : carts) {
			if (cart1.getName().equals(cart.getName())) {
				increaseQty(name,request);
				flag = 1;
			}
		}

		if (flag == 0) {
			carts.add(cart);
		}
      return "redirect:/viewCart";
	}
	
	@RequestMapping("/removeProduct")
	public String removeProduct(@RequestParam("name") String name,HttpServletRequest request) {
		HttpSession session = request.getSession();
		//String addby = (String) session.getAttribute("user");
		for (int i=0;i<carts.size();i++) {
			Cart cart=carts.get(i);
			if(cart.getName().equals(name)) {
				carts.remove(i);
			}
		}
		return "redirect:/viewCart";
	}
	
	@RequestMapping("/decreaseProduct")
	public String decreaseQty(@RequestParam("name") String name,HttpServletRequest request) {
		HttpSession session = request.getSession();
		//String addby = (String) session.getAttribute("user");
		for (Cart cart1 : carts) {
			if (cart1.getName().equals(name)) {
				if(cart1.getQty()==1) {
					removeProduct(name, request);
				}else {
				cart1.setPrice(cart1.getPrice() - (cart1.getPrice()/cart1.getQty()));
				cart1.setQty(cart1.getQty() - 1);	
				}
			}
		}
		return "redirect:/viewCart";
	}
	
	@RequestMapping("/increaseProduct")
	public String increaseQty(@RequestParam("name") String name,HttpServletRequest request) {
		HttpSession session = request.getSession();
		//String addby = (String) session.getAttribute("user");
		String str=null;
		for (int i = 0; i < carts.size(); i++) {
			Cart p = carts.get(i);
			if (p.getName().equals(name)) {
				if (p.getQty()==p.getpQty()) {
					str = name + " is not sufficiently available";
				} else {
					p.setPrice(p.getPrice() + p.getPrice()/p.getQty());
					p.setQty(p.getQty() + 1);
					str = "increased";
				}
			}
		}
		return "redirect:/viewCart";
	}
	
	@RequestMapping("/viewCart")
	public String viewCart(ModelMap modelMap) {
		
		return "redirect:/home"; 
	}

}
