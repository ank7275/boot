package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import oracle.net.aso.c;

@org.springframework.stereotype.Service
public class Service {
	@Autowired
	AdminRepository adminRepository;
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	ProductRepository productRepository;
	
	@PersistenceContext 
	private EntityManager entityManager;
	
	public void saveadmin(Admin admin) {
		if(!adminRepository.existsById(admin.getAdminEmail()))
		adminRepository.save(admin);
	}
	
	public void savecustomer(Customer customer) {
		if(!customerRepository.existsById(customer.getcEmail()))
			customerRepository.save(customer);
	}
	
	public Optional<Customer> getDetails(String email) {
		return customerRepository.findById(email);
	}
	
	public void addproduct(Product product) {
		productRepository.save(product);
	}
	
	public List<Product> getAllProducts(){
		List<Product> products=new ArrayList<Product>();
		   productRepository.findAll().forEach(products::add);
		   return products;
	}
	
	public Optional<Product> getProduct(int id){
		return productRepository.findById(id);
	}
	
	public List<Product> search(String val){
		Session session = null;
		if (entityManager == null
		   || (session = entityManager.unwrap(Session.class)) == null) {

		   throw new NullPointerException();
		}
		Criteria criteria=session.createCriteria(Product.class).add(Restrictions.ilike("proName",val+"%"));
		return criteria.list();
	}

}
