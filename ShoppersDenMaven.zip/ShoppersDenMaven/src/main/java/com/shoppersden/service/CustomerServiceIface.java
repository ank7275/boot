package com.shoppersden.service;

import com.shoppersden.model.Customer;

public interface CustomerServiceIface {
	String addCustomerService(Customer c);

	Customer verifyCustomerService(String email, String pass);

	String updateCustomerService(Customer customer);

	Customer getCustomerDetailsService(String uid);

	int validateIdService(String id);

	int updatePasswordService(String id, String pass);
}
