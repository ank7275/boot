package com.shoppersden.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shoppersden.dao.AdminDaoIface;
import com.shoppersden.model.Admin;

@Service
public class AdminService implements AdminServiceIface {
	@Autowired
	AdminDaoIface adminDaoIface;

	@Override
	public String registerAdminService(Admin admin) {
		return adminDaoIface.registerAdmin(admin);
	}

	@Override
	public Admin verifyAdminService(String id, String pass) {
		return adminDaoIface.verifyAdmin(id, pass);
	}
	
	public String checkEmailExistanceService(String adminId) {
		return adminDaoIface.checkEmailExistance(adminId);
	}

}
