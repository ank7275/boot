package com.shoppersden.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.shoppersden.dao.CustomerDao;
import com.shoppersden.model.Customer;

class CustomerTest {

	@Test
	public void testAddCustomer() {
		Customer obj1 = new Customer();
		obj1.setcGender("MALE");
		obj1.setcEmail("Vijay@gmail.com");
		obj1.setcDob("03-11-1996");
		obj1.setcContact("9540221967");
		obj1.setcAddress("Hyderabad");
		obj1.setcName("Vijay");
		obj1.setcPass("Vijay@000");
		assertEquals("customer Account created", new CustomerDao().addCustomer(obj1));

	}

}
