package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Transient;

public class Cart {
	
	@Id
	private int cid;
	
	@Column
	private String name;
	
	@Column
	private int pid;
	
	@Column
	private int qty;
	
	@Column
	private String addby;
	
	@Column
	private int price;
	
	@Transient
	private int pQty;
	
	

	public Cart(String name, int pid, int qty, String addby, int price, int pQty) {
		super();
		this.name = name;
		this.pid = pid;
		this.qty = qty;
		this.addby = addby;
		this.price = price;
		this.pQty = pQty;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public String getAddby() {
		return addby;
	}

	public void setAddby(String addby) {
		this.addby = addby;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getpQty() {
		return pQty;
	}

	public void setpQty(int pQty) {
		this.pQty = pQty;
	}
	
	

}
