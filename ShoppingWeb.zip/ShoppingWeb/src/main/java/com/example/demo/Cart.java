package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="orders")
public class Cart {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int cid;
	
	@Column
	private String name;
	
	@Column
	private int pid;
	
	@Column
	private int qty;
	
	@Column
	private String addby;
	
	@Column
	private int price;
	
	@Transient
	private int pQty;
	
	@Column
	private String oid;
	
	@ManyToOne
	@JoinColumn(name="oid",referencedColumnName="orderid",insertable=false,updatable=false)
	private Orders orders;
    
	public Cart() {
		
	}
	
	public Cart(String name, int pid, int qty, String addby, int price, int pQty) {
		super();
		this.name = name;
		this.pid = pid;
		this.qty = qty;
		this.addby = addby;
		this.price = price;
		this.pQty = pQty;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public String getAddby() {
		return addby;
	}

	public void setAddby(String addby) {
		this.addby = addby;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getpQty() {
		return pQty;
	}

	public void setpQty(int pQty) {
		this.pQty = pQty;
	}


	public String getOid() {
		return oid;
	}


	public void setOid(String oid) {
		this.oid = oid;
	}


	public Orders getOrders() {
		return orders;
	}


	public void setOrders(Orders orders) {
		this.orders = orders;
	}

}
