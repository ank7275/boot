package com.shoppersden.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.shoppersden.dao.AdminDao;
import com.shoppersden.model.Admin;

class AdminTest {
	@Test
	public void testGetters() {
		Admin obj = new Admin();

		obj.setAdminName("Ankit");
		assertEquals("Ankit", obj.getAdminName());

		obj.setAdminPassword("ankit");
		assertEquals("ankit", obj.getAdminPassword());

	}

	public void testVerifyAdmin() {

		assertEquals("Invalid", new AdminDao().verifyAdmin("null", "null"));
		assertEquals("Indralok", new AdminDao().verifyAdmin("ADMIN001", "Ankit@123"));
	}

}
