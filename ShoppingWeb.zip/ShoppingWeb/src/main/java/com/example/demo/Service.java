package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

@org.springframework.stereotype.Service
public class Service {
	@Autowired
	AdminRepository adminRepository;
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	ProductRepository productRepository;
	
	public void saveadmin(Admin admin) {
		if(!adminRepository.existsById(admin.getAdminEmail()))
		adminRepository.save(admin);
	}
	
	public void savecustomer(Customer customer) {
		if(!customerRepository.existsById(customer.getcEmail()))
			customerRepository.save(customer);
	}
	
	public Optional<Customer> getDetails(String email) {
		return customerRepository.findById(email);
	}
	
	public void addproduct(Product product) {
		productRepository.save(product);
	}
	
	public List<Product> getAllProducts(){
		List<Product> products=new ArrayList<Product>();
		   productRepository.findAll().forEach(products::add);
		   return products;
	}
	
	public Optional<Product> getProduct(int id){
		return productRepository.findById(id);
	}

}
