package com.shoppersden.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.shoppersden.model.Customer;

/**
 * @author Amita
 *
 */
@Repository
public class CustomerDao implements CustomerDaoIface {
	@Autowired
	SessionFactory sessionFactory;

	@Transactional
	public String addCustomer(Customer cust) {
        String msg = this.checkCustomerEmail(cust.getcEmail());
        if(msg == null) {
		String result = (String) sessionFactory.getCurrentSession().save(cust);
		if (result != null) {
			return "Customer added successfully";
		} else {
			return "Customer not added successfully";
		}
        }else {
        	return "Use different email id";
        }
	}

	@Transactional
	public Customer verifyCustomer(String email, String pass) {
		Customer customer = (Customer) sessionFactory.getCurrentSession().get(Customer.class, email);
		if (customer != null) {
			if (customer.getcPass().equals(pass)) {
				return customer;
			} else {
				return null;
			}
		} else {
			return null;
		}

	}

	@Transactional
	public String updateCustomer(Customer customer) {
		sessionFactory.getCurrentSession().saveOrUpdate(customer);
		return "Successfully updated";

	}

	@Transactional
	public Customer getCustomerDetails(String uid) {

		List<Customer> customers = (List<Customer>) sessionFactory.getCurrentSession().createQuery("from Customer")
				.list();
		if (customers != null) {
			for (Customer customer : customers) {
				if (customer.getcEmail().equals(uid)) {
					return customer;
				}
			}

		}
		return null;
	}

	@Transactional
	public int validateId(String id) {
		Customer customer = (Customer) sessionFactory.getCurrentSession().get(Customer.class, id);
		if(customer!=null) {
			return 1;
		}else {
			return 0;
		}
	}
    @Transactional
	public int updatePassword(String id, String pass) {
		Query query = sessionFactory.getCurrentSession()
				.createQuery("update Customer set cPass=:pass where cEmail=:id");
		query.setParameter("pass", pass);
		query.setParameter("id", id);
		return query.executeUpdate();
	}
    public String checkCustomerEmail(String email) {
    	Customer customer = (Customer) sessionFactory.getCurrentSession().get(Customer.class, email);
		if (customer != null) {
			return "email already exists";
		} else {
			return null;
		}
    }

}
