package com.example.demo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends CrudRepository<Product,Integer>{

	List<Product> findAllBypostedBy(String user);
	List<Product> findAllBycatId(int id);

}
