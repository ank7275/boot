package com.shoppersden.dao;

import java.util.List;

import com.shoppersden.model.Category;

public interface CategoryDaoIface {
    public String addCategory(Category category);
    public List<Category> showCategory();
    public void updateCategory(Category category);
	public void deleteCategory(int cid);
	public Category getCategory(int cid);
	
}
