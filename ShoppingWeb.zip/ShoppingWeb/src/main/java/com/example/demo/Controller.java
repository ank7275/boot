package com.example.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.context.ServletConfigAware;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;

@org.springframework.stereotype.Controller
public class Controller implements ServletConfigAware, ServletContextAware {
	private ArrayList<Cart> carts = null;
	private ServletContext context = null;
	private ServletConfig config = null;

	@Autowired
	Service service;

	@Override
	public void setServletContext(ServletContext servletContext) {
		this.context = servletContext;

	}

	@Override
	public void setServletConfig(ServletConfig servletConfig) {
		this.config = servletConfig;

	}

	@RequestMapping("/home")
	public String home(ModelMap modelMap) {
		List<Product> products = service.getAllProducts();
		modelMap.addAttribute("products", products);
		modelMap.addAttribute("cart", carts);
		return "home";
	}

	@RequestMapping("/Login")
	public String login(@RequestParam("username") String id, @RequestParam("password") String pass, HttpServletRequest request,
			ModelMap modelMap) {
		if (service.login(id, pass).equals("customer")) {
			HttpSession session = request.getSession();
			session.setAttribute("user", id);
			modelMap.addAttribute("feedback","Successfully login");
			return "redirect:/customer";
		} else if (service.login(id, pass).equals("admin")) {
			modelMap.replace("feedback","Successfully login");
			HttpSession session = request.getSession();
			session.setAttribute("user", id);
			return "redirect:/admin";
		} else {
			modelMap.replace("feedback","invalid credentials");
			return "home";
		}
	}

	@RequestMapping("/customer")
	public String customer(ModelMap modelMap, HttpServletRequest request) {
		HttpSession session = request.getSession();
		Optional<Users> optional = service.getDetails((String) session.getAttribute("user"));
		Users customer = (Users) optional.get();
		session.setAttribute("customer", customer);
		List<Product> products = service.getAllProducts();
		modelMap.addAttribute("opencards", request.getAttribute("opencards"));
		modelMap.addAttribute("products", products);
		modelMap.addAttribute("cart", carts);
		List<Orders> orders = service.getAllOrders((String) session.getAttribute("user"));
		modelMap.addAttribute("orders", orders);
		List<Category> categories = service.getCategory();
		modelMap.addAttribute("category", categories);
		modelMap.addAttribute("card", service.getCards((String) session.getAttribute("user")));
		if (carts == null || carts.size() == 0) {
			modelMap.addAttribute("cartsize", 0);
			modelMap.addAttribute("msg1", "cart is empty");
		} else {
			modelMap.addAttribute("cartsize", carts.size());
			modelMap.addAttribute("msg", request.getParameter("msg"));
		}
		return "Customer";
	}

	@RequestMapping("/admin")
	public String admin(ModelMap modelMap, @SessionAttribute("user") String user) {
		List<Product> products = service.getAllProductAdmin(user);
		modelMap.addAttribute("products", products);
		modelMap.addAttribute("category", service.getCategory());
		return "Admin";
	}

	@RequestMapping("/AddAdmin")
	public String registeradmin(@ModelAttribute Admin admin) {
		int randomid = (int) (Math.random() * 9000) + 1000;
		String val = "" + randomid;
		admin.setUsername("Admin"+val);
		admin.setRole("ADMIN");
		service.saveadmin(admin);
		return "redirect:/administrator";
	}

	@RequestMapping("/deleteAdmin")
	public String deleteAdmin(@RequestParam("id") String id) {
		service.deleteAdmin(id);
		return "redirect:/administrator";
	}

	@RequestMapping("/AddCustomer")
	public String registercustomer(@ModelAttribute Customer customer, ModelMap m) {
		m.addAttribute("message", "Customer Registered Successfully");
		customer.setRole("USER");
		service.savecustomer(customer);
		return "home";

	}

	@RequestMapping("/deleteCustomer")
	public String deleteCustomer(@RequestParam("id") String id) {
		service.deleteCustomer(id);
		return "redirect:/administrator";
	}

	@RequestMapping("/GetDetails")
	public void getCustDetails(@RequestParam("email") String email, HttpServletResponse response) {
		Optional<Users> optional = service.getDetails(email);
		if (optional.isPresent()) {
			Users customer = (Users) optional.get();
			String json = new Gson().toJson(customer);
			PrintWriter printWriter;
			try {
				printWriter = response.getWriter();
				printWriter.print(json);
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	@RequestMapping("/addProduct")
	public String addProduct(@ModelAttribute Product product, @SessionAttribute("user") String user) {
		product.setPostedBy(user);
		service.addproduct(product);
		return "redirect:/admin";
	}

	@RequestMapping("/updateProduct")
	public void getProDetails(@RequestParam("id") int id, HttpServletResponse response) {
		Optional<Product> optional = service.getProduct(id);
		if (optional.isPresent()) {
			Product product = (Product) optional.get();
			System.out.println(product);
			String json = new Gson().toJson(product);
			PrintWriter printWriter;
			try {
				printWriter = response.getWriter();
				printWriter.print(json);
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	@RequestMapping("/RemoveProduct")
	public String removepro(@RequestParam("id") int id) {
		service.removeProduct(id);
		return "redirect:/admin";
	}

	@RequestMapping("/AjaxSearch")
	public void search(@RequestParam("val") String val, ModelMap modelMap, HttpServletResponse response) {
		List<Product> products = service.search(val);
		String json = new Gson().toJson(products);
		PrintWriter printWriter;
		try {
			printWriter = response.getWriter();
			printWriter.print(json);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@RequestMapping("/searchByCat")
	public void searchBycategory(@RequestParam("cid") int cid, HttpServletResponse response) {

		List<Product> products = service.searchByCategory(cid);
		String json = new Gson().toJson(products);
		PrintWriter printWriter;
		try {
			printWriter = response.getWriter();
			printWriter.print(json);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@RequestMapping("/AddToCart")
	public String addToCart(@SessionAttribute("user") String user,@RequestParam("id") int pid, @RequestParam("name") String name,
			@RequestParam("price") int price, @RequestParam("qty") int qty, Model m) {
		Cart cart = new Cart(name, pid, 1,user, price, qty);
		int flag = 0;
		if (carts == null) {
			carts = new ArrayList<Cart>();
		}

		for (Cart cart1 : carts) {
			if (cart1.getName().equals(cart.getName()) && cart1.getAddby().equals(user)) {
				increaseQty(user,name);
				flag = 1;
			}
		}

		if (flag == 0) {
			carts.add(cart);
		}

		return "redirect:/viewCart";
	}

	@RequestMapping("/removeProduct")
	public String removeProduct(@SessionAttribute("user") String user,@RequestParam("name") String name) {
		for (int i = 0; i < carts.size(); i++) {
			Cart cart = carts.get(i);
			if (cart.getName().equals(name) && cart.getAddby().equals(user)) {
				carts.remove(i);
			}
		}
		return "redirect:/viewCart";
	}

	@RequestMapping("/decreaseProduct")
	public String decreaseQty(@SessionAttribute("user") String user,@RequestParam("name") String name, HttpServletRequest request) {
			for (Cart cart1 : carts) {
			if (cart1.getName().equals(name) && cart1.getAddby().equals(user)) {
				if (cart1.getQty() == 1) {
					removeProduct(user,name);
				} else {
					cart1.setPrice(cart1.getPrice() - (cart1.getPrice() / cart1.getQty()));
					cart1.setQty(cart1.getQty() - 1);
				}
			}
		}
		return "redirect:/viewCart";
	}

	@RequestMapping("/increaseProduct")
	public ModelAndView increaseQty(@SessionAttribute("user") String user,@RequestParam("name") String name) {
		String str = null;
		for (int i = 0; i < carts.size(); i++) {
			Cart p = carts.get(i);
			if (p.getName().equals(name) && p.getAddby().equals(user)) {
				if (p.getQty() == p.getpQty()) {
					str = name + " is not sufficiently available";
				} else {
					p.setPrice(p.getPrice() + p.getPrice() / p.getQty());
					p.setQty(p.getQty() + 1);
				}
			}
		}
		return new ModelAndView("redirect:/viewCart", "msg", str);
	}

	@RequestMapping("/viewCart")
	public ModelAndView viewCart(HttpServletRequest request) {
		HttpSession session = request.getSession();
		if (session == null) {
			return new ModelAndView("redirect:/home", "msg", request.getParameter("msg"));
		} else {
			return new ModelAndView("redirect:/customer", "msg", request.getParameter("msg"));
		}
	}

	@RequestMapping("/addCard")
	public String addcard(@ModelAttribute Card card) {
		service.savecard(card);
		return "redirect:/customer";
	}

	@RequestMapping("/GetCards")
	public void getCards(@RequestParam("user") String user, HttpServletResponse response) {
		List<Card> cards = service.getCards(user);
		String json = new Gson().toJson(cards);
		PrintWriter printWriter;
		try {
			printWriter = response.getWriter();
			printWriter.print(json);
		} catch (IOException e) {
// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@RequestMapping("/deleteCard")
	public String deleteCard(@RequestParam("cno") String cno, ModelMap m) {
		service.deleteCard(cno);
		return "redirect:/customer";
	}

	@RequestMapping("/logout")
	public String invalidate(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.removeAttribute("user");
		session.invalidate();
		return "redirect:/home";
	}

	@RequestMapping("/Billing")
	public String billing(@RequestParam("qty") int qty, @RequestParam("price") int price, ModelMap modelMap,@SessionAttribute("user") String user) {
		modelMap.addAttribute("qty", qty);
		modelMap.addAttribute("price", price);
		modelMap.addAttribute("card", service.getCards(user));
		return "payment";
	}

	@RequestMapping("/ConfirmOrder")
	public String order(@ModelAttribute Transaction transaction, HttpServletRequest request) {
		HttpSession session = request.getSession();
		int randomid = (int) (Math.random() * 9000) + 1000;
		String val = "" + randomid;
		transaction.setStatus("pending");
		Calendar calendar;
		calendar = Calendar.getInstance();
		transaction.setOdate(calendar.getTime());
		calendar.add(Calendar.DAY_OF_MONTH, 3);
		transaction.setDdate(calendar.getTime());
		if (request.getParameter("cod") != null) {
			transaction.setPaymenttype("cash on delivery");
		} else {
			transaction.setPaymenttype("card");
		}
		Orders orders = new Orders();
		orders.setOrderid(val);
		orders.setUserid((String) session.getAttribute("user"));
		transaction.setOid(orders.getOrderid());
		orders.setTransaction(transaction);
		for (Cart cart : carts) {
			cart.setOid(orders.getOrderid());
		}
		orders.setCarts(carts);
		service.saveOrders(orders);
		carts = null;
		return "redirect:/customer";
	}

	@RequestMapping("/addCategory")
	public String addCategory(@ModelAttribute Category category) {
		service.addCategory(category);
		return "redirect:/administrator";
	}

	@RequestMapping("/deleteCategory")
	public String deleteCategory(@RequestParam("id") int id) {
		service.deleteCategory(id);
		return "redirect:/administrator";
	}

	@RequestMapping("/administrator")
	public String administrator(ModelMap m) {
		m.addAttribute("category", service.getCategory());
		m.addAttribute("admin", service.getAdmins());
		m.addAttribute("customer", service.getCustomers());
		return "administrator";
	}

	@RequestMapping("/cancelorder")
	public String cancelorder(@RequestParam("oid") String oid) {
		Transaction transaction = service.cancelOrder(oid);
		transaction.setStatus("cancelled");
		service.savetrans(transaction);
		return "redirect:/customer";
	}
	
	@RequestMapping("/login")
	public String loginform() {
		return "login";
	}
}