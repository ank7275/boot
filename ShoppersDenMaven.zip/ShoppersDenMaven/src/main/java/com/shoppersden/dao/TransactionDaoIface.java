package com.shoppersden.dao;

import java.util.List;

import com.shoppersden.model.Transactions;

public interface TransactionDaoIface {
	void insertTransaction(Transactions transactions);
	List<Transactions> getAllTransactions();
}
