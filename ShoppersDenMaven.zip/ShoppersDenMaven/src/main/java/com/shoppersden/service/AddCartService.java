package com.shoppersden.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shoppersden.dao.AddCartDaoIface;
import com.shoppersden.model.Cart;
@Service
public class AddCartService implements AddCartServiceIface{
	@Autowired
     AddCartDaoIface af;
	public String AddToCartService(Cart obj) {
		return af.AddToCart(obj);
	}
	public ArrayList<Cart> displayCartService() {
		return af.displayCart();
	}
	public String removeCartService(String name) {
		return af.removeCart(name);
	}
	public String decreaseQtyService(String name) {
		return af.decreaseQty(name);
	}

	public String increaseQtyService(String name) {
		return af.increaseQty(name);
	}
	public int cartSize() {
		return af.cartSize();
	}
	public void setCart(ArrayList<Cart> cart) {
		af.setCart(cart);
	}

}
