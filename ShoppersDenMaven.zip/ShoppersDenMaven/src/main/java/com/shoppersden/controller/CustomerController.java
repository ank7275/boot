package com.shoppersden.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.ServletConfigAware;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.servlet.ModelAndView;

import com.shoppersden.dao.CartDaoIface;
import com.shoppersden.model.Card;
import com.shoppersden.model.Cart;
import com.shoppersden.model.Category;
import com.shoppersden.model.Customer;
import com.shoppersden.model.MyOrders;
import com.shoppersden.model.Product;
import com.shoppersden.model.Transactions;
import com.shoppersden.service.AddCartServiceIface;
import com.shoppersden.service.CardServiceIface;
import com.shoppersden.service.CategoryServiceIface;
import com.shoppersden.service.CustomerServiceIface;
import com.shoppersden.service.MyOrderServiceIface;
import com.shoppersden.service.ProductServiceIface;
import com.shoppersden.service.TransactionServiceIface;

/**
 * @author Ankit & Amita
 *
 */
@Controller
public class CustomerController implements ServletConfigAware, ServletContextAware {
	@Autowired
	CustomerServiceIface customerIface;
	@Autowired
	ProductServiceIface productIface;
	@Autowired
	CardServiceIface cardIface;
	@Autowired
	CategoryServiceIface categoryServiceIface;
	@Autowired
	TransactionServiceIface transactionServiceIface;
	@Autowired
	MyOrderServiceIface myOrderServiceIface;
	@Autowired
	CartDaoIface cartDaoIface;
	@Autowired
	AddCartServiceIface addCartServiceIface;

	ServletConfig config;
	ServletContext context;

	@Override
	public void setServletContext(ServletContext servletContext) {
		this.context = servletContext;

	}

	@Override
	public void setServletConfig(ServletConfig servletConfig) {

		this.config = servletConfig;
	}

	@RequestMapping("/CustomerPage")
	public ModelAndView showCustomerPage(Model m) {
		context = config.getServletContext();
		List<Product> product = productIface.getAllProductService();
		List<Category> categories = categoryServiceIface.showCategoryService();
		context.setAttribute("category", categories);

		m.addAttribute("cartsize", addCartServiceIface.cartSize());
		return new ModelAndView("Customer", "product", product);
	}

	@RequestMapping("/CustomerUpdateForm")
	public ModelAndView showUpdateForm(HttpSession session, HttpServletRequest request) {
		session = request.getSession();
		String user = (String) session.getAttribute("cname");
		Customer customer = customerIface.getCustomerDetailsService(user);
		return new ModelAndView("CustomerUpdate", "customer", customer);
	}

	@RequestMapping("/UpdateCustomer")
	public String updateCustomer(@ModelAttribute Customer customer) {
		customerIface.updateCustomerService(customer);
		return "redirect:CustomerPage";
	}

	@RequestMapping("/ViewCards")
	public ModelAndView viewCards(HttpSession session, HttpServletRequest request) {
		session = request.getSession();
		String id = (String) session.getAttribute("cname");
		List<Card> cards = cardIface.getAllCardService(id);
		return new ModelAndView("CardDetails", "card", cards);
	}

	@RequestMapping("/SelectCard")
	public String showCards(HttpSession session, HttpServletRequest request, Model m) {
		session = request.getSession();
		if (session == null || session.getAttribute("cname") == null) {
			m.addAttribute("msg", "No user is logged in");
			return "Loginform";
		} else {
			String id = (String) session.getAttribute("cname");
			List<Card> cards = cardIface.getAllCardService(id);
			m.addAttribute("cards", cards);
			m.addAttribute("totalAmount", request.getParameter("total"));
			m.addAttribute("totalQty", request.getParameter("qty"));
			return "SelectCard";
		}
	}

	@RequestMapping("/BillingInfo")
	public String billingInfo(HttpSession session, HttpServletRequest request, Model m) {
		session = request.getSession();
		String id = (String) session.getAttribute("cname");
		Customer customer = customerIface.getCustomerDetailsService(id);
		m.addAttribute("bill", request.getParameter("bill"));
		m.addAttribute("qty", request.getParameter("qty"));
		m.addAttribute("no", request.getParameter("no"));
		m.addAttribute("customer", customer);
		return "Billing";
	}

	@RequestMapping("/ConfirmOrder")
	public String confirmOrder(@ModelAttribute Transactions transactions, HttpServletRequest request,
			HttpSession session, Model m) {
		MyOrders myOrders = new MyOrders();
		myOrders.setUserid((String) request.getSession().getAttribute("cname"));
		myOrderServiceIface.addOrderService(myOrders);
		transactions.setOid(myOrders.getOrderid());
		transactionServiceIface.insertTransactionService(transactions);
		ArrayList<Cart> carts = addCartServiceIface.displayCartService();
		for (Cart cart : carts) {
			Cart cart2 = new Cart();
			cart2.setOid(myOrders.getOrderid());
			cart2.setProid(cart.getProid());
			cart2.setName(cart.getName());
			cart2.setcPrice(cart.getcPrice());
			cart2.setcQty(cart.getcQty());
			productIface.qtyUpdateProductService(cart.getName(), cart.getcQty());
			cartDaoIface.saveAllorders(cart2);
		}
		context.setAttribute("cartsize", 0);
		addCartServiceIface.setCart(null);
		m.addAttribute("cart", carts);
		m.addAttribute("transaction", transactions);
		return "Confirm";
	}

	@RequestMapping("/viewOrders")
	public String viewOrders(HttpServletRequest request, HttpSession session, Model m) {
		List<Integer> myOrders = myOrderServiceIface
				.getOrdersService((String) request.getSession().getAttribute("cname"));
		List<Cart> carts = cartDaoIface.getAllOrderedItems();
		List<Transactions> transactions = transactionServiceIface.getAllTransactions();
		m.addAttribute("transactions", transactions);
		m.addAttribute("myorders", myOrders);
		m.addAttribute("items", carts);
		return "MyOrders";
	}

	@RequestMapping("/CancelOrder")
	public String cancelOrder(@RequestParam("orderid") int oid) {
		myOrderServiceIface.cancelOrderService(oid);
		return "redirect:/viewOrders";
	}
	
	@RequestMapping("/faq")
	public String faqPage() {
		return "faq";
	}
}
