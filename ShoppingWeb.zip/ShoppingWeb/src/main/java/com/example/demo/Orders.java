package com.example.demo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="custorder")
public class Orders {
	
	@Id
	private String orderid;
	
	@Column
	private String uid;
	
	@OneToMany(cascade=CascadeType.ALL,mappedBy="orders")
	private List<Cart> carts;
	
	
	@OneToOne(cascade=CascadeType.ALL,mappedBy="orders")
	private Transaction transaction;	

	public String getOrderid() {
		return orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}

	public String getUserid() {
		return uid;
	}

	public void setUserid(String userid) {
		this.uid = userid;
	}

	public List<Cart> getCarts() {
		return carts;
	}

	public void setCarts(List<Cart> carts) {
		this.carts = carts;
	}

	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	
	
	
	
}
