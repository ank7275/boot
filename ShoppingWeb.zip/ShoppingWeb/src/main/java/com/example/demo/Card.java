package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="card1")
public class Card {
	@Id
	@Column
	private String cno;
	@Column
	private String userid;
	@Column
	private String cccv;
	@Column
	private String cexpMonth;
	@Column
	private String cexpYear;
	@Column
	private String chName;

	public String getCno() {
		return cno;
	}
	public void setCno(String cno) {
		this.cno = cno;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getCccv() {
		return cccv;
	}

	public void setCccv(String cccv) {
		this.cccv = cccv;
	}

	public String getCexpMonth() {
		return cexpMonth;
	}

	public void setCexpMonth(String cexpMonth) {
		this.cexpMonth = cexpMonth;
	}

	public String getCexpYear() {
		return cexpYear;
	}

	public void setCexpYear(String cexpYear) {
		this.cexpYear = cexpYear;
	}

	public String getChName() {
		return chName;
	}

	public void setChName(String chName) {
		this.chName = chName;
	}

}
