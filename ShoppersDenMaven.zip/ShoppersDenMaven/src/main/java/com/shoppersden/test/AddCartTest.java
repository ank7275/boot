package com.shoppersden.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.shoppersden.dao.AddCartDao;
import com.shoppersden.model.Cart;

class AddCartTest {

	@Test
	public void addToCarttest() {
		Cart obj = new Cart(1, "oil", 34, 5);
		assertEquals("Added Successful", new AddCartDao().AddToCart(obj));
	}

	@Test
	public void decreaseQty() {
		assertEquals("decreased", new AddCartDao().decreaseQty("oil"));
	}

	@Test
	public void increaseQty() {
		assertEquals("increased", new AddCartDao().increaseQty("oil"));
	}

	@Test
	public void removeQty() {
		assertEquals("Removed", new AddCartDao().removeCart("oil"));
	}

	@Test
	public void sizeTest() {
		assertEquals(1,new AddCartDao().cartSize());
	}

}
