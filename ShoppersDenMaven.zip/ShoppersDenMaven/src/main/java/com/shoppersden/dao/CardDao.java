package com.shoppersden.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shoppersden.model.Card;

/**
 * @author Supriya
 *
 */
@Repository
public class CardDao implements CardDaoIface {
	@Autowired
	SessionFactory sessionFactory;
	static Logger logger = Logger.getLogger(Card.class);

	@Transactional
	public String addCard(Card card) {
		String cno = (String) sessionFactory.getCurrentSession().save(card);
		if (cno != null) {
			return "Card Added Successfully";
		} else {
			return "Card Not added";
		}
	}

	@Transactional
	public String deleteCard(String cno) {
		Query query = sessionFactory.getCurrentSession().createQuery("delete from Card where cno=:cno");
		query.setParameter("cno", cno);
		int i = query.executeUpdate();
		if (i > 0) {
			return "deleted Successfully";
		} else {
			return "Card Not found";
		}
	}

	@Transactional
	public List<Card> getAllCard(String user) {
		Query query = sessionFactory.getCurrentSession().createQuery("from Card where userid=:id");
		query.setParameter("id", user);
		List<Card> cards = query.list();
		return cards;

	}

}
