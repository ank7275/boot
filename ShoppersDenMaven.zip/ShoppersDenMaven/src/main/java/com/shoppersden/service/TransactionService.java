package com.shoppersden.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shoppersden.dao.TransactionDaoIface;
import com.shoppersden.model.Transactions;

@Service
public class TransactionService implements TransactionServiceIface {
	@Autowired
	TransactionDaoIface transactionDaoIface;

	public void insertTransactionService(Transactions transactions) {
		transactionDaoIface.insertTransaction(transactions);
	}

	public List<Transactions> getAllTransactions() {
		return transactionDaoIface.getAllTransactions();
	}
}
