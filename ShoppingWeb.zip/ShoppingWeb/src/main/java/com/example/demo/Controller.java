package com.example.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.gson.Gson;


@org.springframework.stereotype.Controller
public class Controller {
	@Autowired
	Service service;
	
	@RequestMapping("/home")
	public String home() {
		return "home";
	}

	@RequestMapping("/admin")
	public String admin(ModelMap modelMap) {
		List<Product> products=service.getAllProducts();
		modelMap.addAttribute("products",products);
		return "Admin";
	}
	
	@RequestMapping("/customer")
	public String customer() {
		return "Customer";
	}
	
	@RequestMapping("/AddAdmin")
	public String registeradmin(@ModelAttribute Admin admin) {
			service.saveadmin(admin);
			return "home";
		}
	
	@RequestMapping("/AddCustomer")
	public String registercustomer(@ModelAttribute Customer customer) {
			service.savecustomer(customer);
			return "home";
		}
	
	@RequestMapping("/GetDetails")
	public void getCustDetails(@RequestParam("email") String email,HttpServletResponse response) {
		Optional<Customer> optional=service.getDetails(email);
		if(optional.isPresent()) {
		Customer customer=(Customer)optional.get();
		String json = new Gson().toJson(customer);
		PrintWriter printWriter;
		try {
			printWriter = response.getWriter();
			printWriter.print(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
	}
	
	@RequestMapping("/addProduct")
	public String addProduct(@ModelAttribute Product product) {
		service.addproduct(product);
		return "redirect:/admin";
	}
	
	@RequestMapping("/updateProduct")
	public void getProDetails(@RequestParam("id") int id,HttpServletResponse response) {
		Optional<Product> optional=service.getProduct(id);
		if(optional.isPresent()) {
		Product product=(Product)optional.get();
		System.out.println(product);
		String json = new Gson().toJson(product);
		PrintWriter printWriter;
		try {
			printWriter = response.getWriter();
			printWriter.print(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
	}
	
	
}
