package com.shoppersden.seleniumtest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * @author Ankit
 *
 */
public class SeleniumTest {
	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "G:\\lib\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();

		driver.manage().window().fullscreen();
		driver.get("http://localhost:8096/ShoppersDenMaven/home");
		driver.findElement(By.linkText("Login")).click();
		driver.findElement(By.name("name")).sendKeys("aa@gmail.com");
		driver.findElement(By.name("pass")).sendKeys("Ankit@123");
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/center/div/form/table/tbody/tr[6]/td/input"))
				.click();
		driver.findElement(By.linkText("View catagory")).click();
		driver.findElement(By.linkText("Logout ankit")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/nav/ul/li[1]/a")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div[2]/div/a")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[1]/div[1]/div/form/input")).sendKeys("s");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/nav/ul/li[3]/a")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/center/a")).click();
		driver.findElement(By.name("name")).sendKeys("aa93@gmail.com");
		driver.findElement(By.name("pass")).sendKeys("Ankit@123");
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/center/div/form/table/tbody/tr[6]/td/input"))
				.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/nav/div/ul/li[2]/a/span[1]")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/center/a")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/table/tbody/tr[2]/td[3]/a")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"add\"]")).sendKeys("Gacchibowli");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/center/div/form/center/center/input")).click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/nav/div/ul/li[5]/a")).click();
		JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
		javascriptExecutor.executeScript("window.scrollBy(0,1000)");
	}
}
